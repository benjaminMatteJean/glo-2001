Ce répertoire contient les fichiers pour la question 2. Pour compiler manuellement, faites :
make 
dans ce répertoire. Pour effacer les fichiers non-source, faites
make clean

J'ai inclus aussi un projet Code::Blocks, sous le nom ThreadPool.cdp .


