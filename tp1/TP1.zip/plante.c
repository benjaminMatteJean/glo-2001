int main() {
    int * pointeur = 0;
    int value = *pointeur;
    return 0;
}
